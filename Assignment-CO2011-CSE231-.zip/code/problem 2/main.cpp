
#include "main.h"
#include "EdmondKarp.cpp"

int main(int argc, char *argv[])
{
    string fileName = "test.txt";
    playGround(fileName);

    return 0;
}
